## sed练习题

 

- 写一个脚本, 把mysqld.log日志中5月份之前的记录全部删掉

  ```shell
  #!/usr/bin/env bash
  
  for days in {1..31};do
      {
          sed -ri "/[^.]*${days}\/Jan\/2018[^.]*/d" $1
          sed -ri "/[^.]*${days}\/Feb\/2018[^.]*/d" $1
          sed -ri "/[^.]*${days}\/Mar\/2018[^.]*/d" $1
          sed -ri "/[^.]*${days}\/Apr\/2018[^.]*/d" $1
      }&
  done
  wait
  echo "1 ~ 11 months remove finish..."
  ```

  

- 复制/etc/rc.d/rc.sysinit文件至/tmp目录,将/tmp/rc.sysinit文件中的以至少一个空白字符开头的行的行首加#

  ```shell
  cp /etc/rc.d/rc.sysinit /tmp/
  sed -i 's/\(^[[:space:]]+\)/#\1/' /tmp/rc.sysinit
  ```

  

- 复制/boot/grub/grub.conf至/tmp目录中,删除/tmp/grub.conf文件中每行行首的空白字符

  ```shell
  cp /boot/grub/grub.conf /tmp/
  sed -i 's/^[[:space:]]+//' /tmp/grub.conf
  ```

  

- 为/tmp/grub.conf文件中前三行的行首加#号

  ```shell
  # vim -->> :1,3 s/string/replace/
  
  sed -i '1,3s/^/#/' /tmp/grub.conf
  ```

  

- 将/etc/yum.repos.d/CentOS-Base.repo文件中所有的enabled=0或gpgcheck=0最后的0修改为1

  ```shell
  sed -ie 's/enabled=0/enabled=1/';'s/gpgcheck=0/gpgcheck=1/' /etc/yum.repos.d/CentOS-Base.repo
  ```

  

- 每4小时执行一次对/etc目录的备份, 备份至/backup目录中, 名字中增加当时的时间(形如etc-201904020202)

  ```shell
  mkdir /backup
  
  #!/usr/bin/env bash
  # filepath: /task/backetc.sh
  tar -cJf etc-$(date +%Y%m%d%H%M) /etc
  
  echo "0 */4 * * *	/bin/bash /task/backetc.sh &" >>/var/spool/cron/$(whoami)
  ```

  

- 每天每两小时取当前系统/proc/meminfo文件中的所有以S开头的信息至/stats/memory.txt文件中

  ```shell
  #!/usr/bin/env bash
  # filepath: /task/findSofmemory.sh
  grep ^S.* /proc/meminfo >>/stats/memory.txt
  
  echo "0 */2 * * *	/bin/bash /task/findSofmemory.sh &" >>/var/spool/cron/$(whoami)
  ```

  

  ```
  																### hlions.txt ###
  
  Betty Boop:245-836-8357:635 Cutesy Lane, Hollywood, CA 91464:6/23/23:14500
  
  Igor Chevsky:385-375-8395:3567 Populus Place, Caldwell, NJ 23875:6/18/68:23400
  
  Norma Corder:397-857-2735:74 Pine Street, Dearborn, MI 23874:3/28/45:245700
  
  Jennifer Cowan:548-834-2348:583 Laurel Ave., Kingsville, TX 83745:10/1/35:58900
  
  Jon DeLoach:408-253-3122:123 Park St., San Jose, CA 04086:7/25/53:85100
  
  Karen Evich:284-758-2857:23 Edgecliff Place, Lincoln , NB 92743:7/25/53:85100
  
  Karen Evich:284-758-2867:23 Edgecliff Place, Lincoln, NB 92743:11/3/35:58200
  
  Karen Evich:284-758-2867:23 Edgecliff Place, Lincoln, NB 92743:11/3/35:58200
  
  Fred Fardbarkle:674-843-1385:20 Parak Lane, Duluth, MN 23850:4/12/23:780900
  
  Fred Fardbarkle:674-843-1385:20 Parak Lane, Duluth, MN 23850:4/12/23:780900
  
  Lori Gortz:327-832-5728:3465 Mirlo Street, Peabody, MA 34756:10/2/65:35200
  
  Paco Gutierrez:835-365-1284:454 Easy Street, Decatur, IL 75732:2/28/53:123500
  
  Ephram Hardy:293-259-5395:235 CarltonLane, Joliet, IL 73858:8/12/20:56700
  
  James Ikeda:834-938-8376:23445 Aster Ave., Allentown, NJ 83745:12/1/38:45000
  
  Barbara Kertz:385-573-8326:832 Ponce Drive, Gzary, IN 83756:12/1/46:268500
  
  Lesley Kirstin:408-456-1234:4 Harvard Square, Boston, MA 02133:4/22/62:52600
  
  William Kopf:846-836-2837:6937 Ware Road, Milton, PA 93756:9/21/46:43500
  
  Sir Lancelot:837-835-8257:474 Camelot Boulevard, Bath, WY 28356:5/13/69:24500
  
  Jesse Neal:408-233-8971:45 Rose Terrace, San Francisco, CA 92303:2/3/36:25000
  
  Zippy Pinhead:834-823-8319:2356 Bizarro Ave., Farmount, IL 84357:1/1/67:89500
  
  Arthur Putie:923-835-8745:23 Wimp Lane, Kensington, DL 38758:8/31/69:126000
  ```

- (hlions.txt)把Jon的名字改为JON;  删除头3行; 删除含有Lane的所有行; 打印所有生日在十一月或十二月的行

  ```shell
  sed -i 's/Jon/JON/g' hlions.txt
  sed -i '1,3d' hlions.txt
  sed -i '/[^.]*Lane[^.]*/d' hlions.txt
  
  pass
  ```

  

- (hlions.txt)在以Kare开头的行末尾加上3颗星; 将所有包含Jose的行都替换为JOSE HAS RETIRED; 删除所有空行

  ```shell
  sed -i 's/\(^Kare.*\)/\1\*\*\*/' hlions.txt
  ```

  

- 在/etc/fstab文件中不以#开头的行的行首增加#号

  ```shell
  sed -i 's/\(^[^#]\)/#\1/' /etc/fstab
  ```

  