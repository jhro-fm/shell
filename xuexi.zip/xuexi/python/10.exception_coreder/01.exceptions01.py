# try:
#     print(10/0)
# except ZeroDivisionError as error:
#     print(error)
# # finally:
# #     print('ndjfkabjgka')
# # print(10/0)
# print('你看不能运行吧!~')
#
# try:
#     print(result / 20)
# except (ZeroDivisionError, NameError) as error:
#     print(error)
#
# print('go on...')

try:
    print(result / 90)
except Exception as error:
    print(error)

print('go on...')

