#!/usr/bin/env python3
# coding: utf8
#
# author: bavdu
# date: 2019/08/05
# usage: functions param


# 内部函数可以保护密码等隐私信息
# import pymysql
#
# def connect():
#     def info():
#         user, passwd, host = 'root', '(Bavduer..0808)', '192.168.161.10'
#         return user, passwd, host
#     c = pymysql.connect(user,password,host = info())
#     return c
#
#
# client = connect()


# 节约代码执行的次数

