def abc(param01, param02):
    return param01 + param02

variable = abc(12, 13)
print(variable)

