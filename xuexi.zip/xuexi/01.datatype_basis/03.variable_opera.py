# 四则运算: +、-、*、/
# 整除: //
# 取余: %


number01, number02, number03 = 1, 2, 3

# 四则运算
number04 = number01 + number02
print("number04's result: ", number04)
number04 = number03 - number01
print("number03 - number01 = ", number04)
number04 = number02 * number03
print("number02 * number03 = ", number04)
number04 = number03 / number02
print("number03 / number02 = ", number04)
number04 = number03 / number01
print("number03 / number01 = ", number04)


# 整除
var01, var02 = 10, 4
print(var01 // var02)

# 取余
var03, var04 = 9, 2
print(var03 % var04)
