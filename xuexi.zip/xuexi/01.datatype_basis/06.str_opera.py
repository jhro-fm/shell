
string = '#'

print(string + 'world')
print(string)
print(string * 10)

n = 0
n = n + 1
n += 1
# n -= 2
n *= 3
n *= 6
n /= 2
n /= 2
print(n)
