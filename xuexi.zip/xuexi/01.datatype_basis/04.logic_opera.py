var01, var02 = 3.14, 2

# 逻辑运算符: >、<、>=、<=、!=、==
print(1 > 2)
print(3 < 4)
print(1 != 0)
print(1 >= 3)
print(3 >= 3)

# 逻辑关系运算符: and、or、not
print(1 > 2 and 3 < 4)
print(3 > 4 or 7 < 9)
print(not 2 > 3)


# if框架
# if 2 > 3:
#     print("这个世界怎么了？")
# elif 2 > 1:
#     print('ok')
# else:
#     pass

number01, number02 = 2, 2
number03 = 3

# if number01 > number02:
#     print("number01 is bigger.")
# elif number01 == number02:
#     print("number01 == number02")
# elif number03 == 3:
#     print("number03 is 3 ................")
# else:
#     print("number02 is bigger.")


if number01 > number02:
    print("number01 is bigger.")
elif number01 == number02:
    print("number01 == number02")
    if number03 == 3:
        print("number03 is 3 ................")
else:
    print("number02 is bigger.")


# 队列: 先进先出
# 堆: 先进后出

