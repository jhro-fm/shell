n01, n02 = "hello", "world"
v01, v02 = 11, 12
c01, c02 = 3.14, 4.445

if n01 != n02 and (v01 != v02 or c01 == c02):
    print('true')
else:
    print('false')

# if框架
# if "condition01(表达式: 1>3)":
#     print('增加执行的任务01')
# elif "condition02(表达式: 2>3)":
#     print('增加执行的任务02')
# elif ...
#     pass
# else:
#     print("最后增加的任务n")

# 单条件判断
# if 1 > 2:
#     print('执行任务01')
#     if 1 > 3:
#         print('执行任务02')
# else:
#     print('执行任务03')
#     if 1 > 4:
#         print('执行任务04')

# 变量赋值的方式
var01 = input('please input your number: ')
print(var01)



