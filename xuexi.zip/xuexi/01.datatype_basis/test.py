
# string = 'python'
# print(int(string), type(int(string)))

string = '3.14'
print(float(string), type(float(string)))

if 2 < 3:
    print('v')
print(int(string), type(int(string)))


var01, var02, var03 = 1, 2, 3
