string = 'hello world'

# 替换操作
new_string = string.replace('o', '0', 2)
print(new_string)

# 切割操作
new_list = string.split()
print(new_list)

# 大小写转换
new_string = string.upper()
print(new_string)
new_string = string.lower()
print(new_string)

# 删除首尾空格
string = '  hello '
new_string = string.strip()
print(new_string)
left_string = string.lstrip()
print(left_string)
right_string = string.rstrip()
print(right_string)

