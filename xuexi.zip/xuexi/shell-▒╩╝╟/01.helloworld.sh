#!/usr/bin/env bash
#
# filepath: shell/01.helloworld.sh
# email: hlions@163.com
# author: hlions
# date: 2019/10/12/10-53
# modify_time: 2019/10/12/10-56
# usage: print hello world text.

echo "hello world"
