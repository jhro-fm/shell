#!/usr/bin/env bash



while :
do
  echo "cloud1907是最棒的集体"
done
