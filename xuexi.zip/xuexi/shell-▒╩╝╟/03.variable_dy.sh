#!/usr/bin/env bash
#
# filepath: shell/01.helloworld.sh
# email: hlions@163.com
# author: hlions
# date: 2019/10/12/11:30
# modify_time: @times
# usage: variable dy.


name='假名'
age=38

echo '单引号形式调用: Name: ${name}, Age: ${age}'
echo "双引号形式调用: Name: ${name}, Age: ${age}"
