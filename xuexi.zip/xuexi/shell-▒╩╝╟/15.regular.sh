#!/usr/bin/env bash
#
# ...
# ...


# .*组合在一起产生的效果是?
grep 't.*password' /var/log/mysqld.log
