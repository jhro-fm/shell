#!/usr/bin/env bash
#

echo $PWD
echo $(date +%Y-%m-%d_%H:%M:%S)

