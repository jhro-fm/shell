
number = []
a = input('please input: ')
number.append(a)
print(number)
